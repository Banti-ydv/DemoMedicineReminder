export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyC_CDW2tTd_BrI-UcXR36-UPsJwD-u9D1I",
        authDomain: "medicinereminder-f7713.firebaseapp.com",
        projectId: "medicinereminder-f7713",
        storageBucket: "medicinereminder-f7713.appspot.com",
        messagingSenderId: "959379465611",
        appId: "1:959379465611:web:9c7612ad84f19ef2153b8e",
        measurementId: "G-PJYGDHJNF8",
        vapidKey: "BCdRlw8Cq_brbmZIWE9S8auhx1JN1MsUY07qCrZFB4oZQDT4EIsrddN_Ty--JH_muHv4bXGu2EgefSBBEYgXM-U"

    },
};