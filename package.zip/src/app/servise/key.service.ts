import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class KeyService {

  public login = "http://192.168.1.11:9192/login";
  public signout = 'http://192.168.1.11:8866/signout';
  public register = 'http://192.168.1.11:8866/register';
  public addmedicine = 'http://192.168.1.11:8866/addmedicine';
  public addExercise = 'http://192.168.1.11:8866/addExercise';
  public saveFood = 'http://192.168.1.11:8866/saveFood';
  public takeAppointment = 'http://192.168.1.11:8866/takeAppointment';
  public MyDetailes = 'http://192.168.1.11:8866/MyDetailes';
  public current_photo = 'http://192.168.1.11:8866/photo/current';
  public deleteMydetail = 'http://192.168.1.11:8866/deleteMydetail';
  public upload_photo = 'http://192.168.1.11:8866/upload-photo';
  public updateMydetailes = 'http://192.168.1.11:8866/updateMydetailes';
  public myAppointment = 'http://192.168.1.11:8866/myAppointment';
  public deleteMyAppointmnetdetail = `http://192.168.1.11:8866/deleteMyAppointmnetdetail/`;
  public updateMyAppointment = `http://192.168.1.11:8866/updateMyAppointment/`;
  public myExercise = 'http://192.168.1.11:8866/myExercise';
  public deleteMyExercise = `http://192.168.1.11:8866/deleteMyExercise/`;
  public updateMyExercise = `http://192.168.1.11:8866/updateMyExercise/`;
  public myFood = 'http://192.168.1.11:8866/myFood';
  public deleteMyFood = `http://192.168.1.11:8866/deleteMyFood/`;
  public updateMyFood = `http://192.168.1.11:8866/updateMyFood/`;
  public mymedicine = 'http://192.168.1.11:8866/mymedicine';
  public deleteMyMedicine = `http://192.168.1.11:8866/deleteMyMedicine/`;
  public updateMyMedicine = `http://192.168.1.11:8866/updateMyMedicine/`;
  public SECRET_KEY = "Shubham12345";
  

  constructor() { }
}
