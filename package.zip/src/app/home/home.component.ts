import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

}


// import { Component, OnInit } from '@angular/core';
// import { trigger, transition, style, animate } from '@angular/animations';


// @Component({
//   selector: 'app-home',
//   templateUrl: './home.component.html',
//   styleUrls: ['./home.component.css'],
//   animations: [
//     trigger('upDownAnimation', [
//       transition(':enter', [
//         style({ transform: 'translateY(-50%)', opacity: 0 }),
//         animate('500ms', style({ transform: 'translateY(0)', opacity: 1 }))
//       ])
//     ])
//   ]
// })
// export class HomeComponent implements OnInit {
//   // Component logic goes here

//   ngOnInit() {
//     // Initialization logic goes here
//   }
// }


// import { Component, OnInit } from '@angular/core';
// import { trigger, transition, style, animate } from '@angular/animations';

// @Component({
//   selector: 'app-home',
//   templateUrl: './home.component.html',
//   styleUrls: ['./home.component.css'],
//   animations: [
//     trigger('upDownAnimation', [
//       transition(':enter', [
//         style({ transform: 'translateY(-50%)', opacity: 0 }),
//         animate('500ms ease-out', style({ transform: 'translateY(0)', opacity: 1 }))
//       ])
//     ])
//   ]
// })
// export class HomeComponent implements OnInit {
//   // Component logic goes here

//   ngOnInit() {
//     // Initialization logic goes here
//   }
// }
