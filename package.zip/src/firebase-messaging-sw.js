importScripts("https://www.gstatic.com/firebasejs/9.22.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.22.1/firebase-messaging-compat.js");
firebase.initializeApp({
    apiKey: "AIzaSyC_CDW2tTd_BrI-UcXR36-UPsJwD-u9D1I",
    authDomain: "medicinereminder-f7713.firebaseapp.com",
    projectId: "medicinereminder-f7713",
    storageBucket: "medicinereminder-f7713.appspot.com",
    messagingSenderId: "959379465611",
    appId: "1:959379465611:web:9c7612ad84f19ef2153b8e",
    measurementId: "G-PJYGDHJNF8"
});
const messaging = firebase.messaging();
